pip3 install --user -r requirements.txt
python3 index
